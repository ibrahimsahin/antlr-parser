package tr.edu.hacettepe.cs.submitdsl;

import java.io.*;
import java.util.*;
import java.io.IOException;
import java.util.zip.*;
import org.antlr.runtime.ANTLRStringStream;
import org.antlr.runtime.CharStream;
import org.antlr.runtime.CommonTokenStream;
import org.antlr.runtime.RecognitionException;
import org.antlr.runtime.TokenStream;

  public class MySubmitDslEngine implements SubmitDslEngine {

	private SubmitModel submitModel = null;
	String subject;
	
	@Override
	public void parseInput(String input) throws RecognitionException {
		CharStream charstream = new ANTLRStringStream(input);
		SubmitDslLexer lexer = new SubmitDslLexer(charstream);
		TokenStream tokenStream = new CommonTokenStream(lexer);
		SubmitDslParser parser = new SubmitDslParser(tokenStream);
		submitModel = parser.parse();

	}

	@Override
	public SubmitModel getSubmitModel() {
		return submitModel;
	}
	
	private String getPath(String directory,String file) {
		directory=directory+file;
		return directory;
	}
	
	private String getDirectoryPath(String directory) {
		directory=directory+"/";
		return directory;
	}
	
	@Override
	public boolean checkSubmission(String zipFilePath) throws IOException {
		// TODO Auto-generated method stub
		MySubmitFormat taken= new MySubmitFormat();
		List<MySubmitFormat> directory = new ArrayList<MySubmitFormat>();
		List<MySubmitFormat> file = new ArrayList<MySubmitFormat>();
		List<MySubmitFormat> recursive = new ArrayList<MySubmitFormat>();
		
		int size=getSubmitModel().getSubmitFormat().size();
		for(int i=0;i<size;i++)
		{
			taken=getSubmitModel().getSubmitFormat().get(i);
			if(taken.numero==2)
			{
				String newDirectory=getDirectoryPath(taken.getElement_name());
				taken.setElement_name(newDirectory);
				directory.add(taken);
			}
			else if(taken.numero==0)
			{
				String newFile=getPath(directory.get(directory.size()-1).getElement_name(),taken.getElement_name());
			    taken.setElement_name(newFile);
			    file.add(taken);
			}
		}
		
		int size_directory=directory.size();
		int size_file=file.size();
		ZipFile zf=new ZipFile(zipFilePath);
		Enumeration<?> e = zf.entries();
		while(e.hasMoreElements()) {
			ZipEntry entry = (ZipEntry) e.nextElement();
            System.out.println("Extracting: " +entry.getName());
            if(entry.isDirectory()){
            	int directory_found=0;
            	MySubmitFormat test_directory= new MySubmitFormat();
            	for(int i=0;i<size_directory;i++)
            	{
            		test_directory=directory.get(i);
            		System.out.println(test_directory.getElement_name());	
            		if(test_directory.getElement_name().equals(entry.getName()))
            		{
            			directory_found=1;
            			directory.get(i).setItem(1);
            			break;
            		}
            	}
            	if(directory_found==0 && (test_directory.getElement_order()[0].equals("mandatory")||test_directory.getElement_order()[1].equals("mandatory")))
            		return false;
            }
            else//entry is not directory
            {
            	MySubmitFormat test_file= new MySubmitFormat();
            	int file_found=0;
            	for(int i=0;i<size_file;i++)
            	{
            		test_file=file.get(i);
            		if(test_file.getElement_name().equals(entry.getName()))
            		{
            			file_found=1;
            			file.get(i).setItem(1);
            			break;
            		}
            	}
            	if(file_found==0){
            		if(test_file.getElement_order()[0].equals("mandatory")||test_file.getElement_order()[1].equals("mandatory")){
            			if(!test_file.getElement_order()[0].equals("folder-recursive") && !test_file.getElement_order()[1].equals("folder-recursive")){
            				return false;
            			}
            		}
            	}
            	if(test_file.getElement_order()[0]!=null && test_file.getElement_order()[0].equals("folder-recursive") )
            		System.out.println("Extra");recursive.add(test_file);
            	if(test_file.getElement_order()[1]!=null && test_file.getElement_order()[1].equals("folder-recursive") )
            		System.out.println("Extra");recursive.add(test_file);
            }
		}
		
		for(int i=0;i<recursive.size();i++)//folder-recursive olanlar� tara
		{
			MySubmitFormat recursive_again = new MySubmitFormat();
			recursive_again=recursive.get(i);
			int recursive_found=0;
			for(int j=0;j<size_file;j++)
			{
				if(file.get(j).getElement_name().equals(recursive_again.getElement_name()))
				{
					recursive_found=1;
					recursive.get(i).setItem(1);
					file.get(j).setItem(1);
				}
				if(recursive_found==0 && (recursive_again.getElement_order()[0]!=null && recursive_again.getElement_order()[0].equals("mandatory")))
						return false;
				if(recursive_found==0 && (recursive_again.getElement_order()[1]!=null && recursive_again.getElement_order()[1].equals("mandatory")))
						return false;
			}
		}
		for(int i=0;i<size_directory;i++)//istenen directory verilmemi�
		{
			MySubmitFormat test= new MySubmitFormat();
			test=directory.get(i);
			if(test.getItem()!=1 && test.getElement_order()[0].equals("mandatory"))
				return false;
		}
		
		for(int i=0;i<size_file;i++)//istenen file verilmemi�
		{
			MySubmitFormat test= new MySubmitFormat();
			test=file.get(i);
			if(test.getItem()!=1 && ((test.getElement_order()!=null && test.getElement_order()[0].equals("mandatory")) || (test.getElement_order()!=null&&test.getElement_order()[1].equals("mandatory"))))
				return false;
		}
		
		System.out.println(file.get(0).getElement_order()[0]);
	   
		return true;
	}
	
}

